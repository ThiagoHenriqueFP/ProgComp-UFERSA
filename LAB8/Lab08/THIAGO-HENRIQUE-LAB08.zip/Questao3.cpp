#include <iostream>

using namespace std;

int main()
{
	float a = 6.1;
	float b = 7.89;
	float c = 1.004;
	float d = 8.9;
	float e = 23.768;
	
	cout << fixed;
	cout.precision(8);

	cout << a << endl << b << endl << c << endl << d << endl << e;


}