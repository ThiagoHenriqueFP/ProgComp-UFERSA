#pragma once
unsigned long long codificar(unsigned __int64);
unsigned long long decodificar(unsigned __int64);
unsigned ligarBit(unsigned, unsigned);
unsigned desligarBit(unsigned, unsigned);
bool testarBit(unsigned, unsigned);