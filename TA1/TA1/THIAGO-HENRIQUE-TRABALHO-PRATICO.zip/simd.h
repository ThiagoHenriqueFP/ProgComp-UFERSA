int armazena(int, int, int, int);
int primeiro(unsigned);
int segundo(unsigned);
int terceiro(unsigned);
int quarto(unsigned);
int soma(unsigned, unsigned);
int mult(unsigned, unsigned); 
